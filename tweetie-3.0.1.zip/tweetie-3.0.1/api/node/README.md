Tweetie Node.js API
===

Simple Node.js API for jQuery Tweetie.

# Config

Edit the `config.js` file and replace the variables with your Twitter Authentication Keys.
